# لغت یار Android project

This project packages the supplied HTML game in an Android WebView. The HTML is bundled locally, so the main game can run offline. The 3D racing renderer in the HTML currently imports Three.js from a CDN and therefore needs internet; if it cannot load, the HTML's fallback racing graphics may be used.

## Build APK using a phone
1. Upload this ZIP to a new GitHub repository (extract it first, so `app/`, `build.gradle`, and `.github/` are at repository root).
2. Open the repository's **Actions** tab and run **Build Loghat Yar APK** (or push to `main`).
3. Open the completed workflow run and download the `loghat-yar-debug-apk` artifact.
4. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open it on your Android phone to install. Android may ask you to allow installs from that browser/files app.

This produces a debug APK for personal testing, not a signed release bundle for Google Play.
